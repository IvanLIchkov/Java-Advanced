package IteratorsAndComparators_19;

public class DemoIterableAndIterator {

}
